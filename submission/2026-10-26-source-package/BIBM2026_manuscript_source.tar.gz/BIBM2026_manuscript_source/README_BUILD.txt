BIBM 2026 Net-AI-BHI manuscript source package
Prepared 26 October 2026. Main entry point: main.tex.

This is the exact, unchanged named manuscript source corresponding to the
25 October 2026 font-clean revision and the returned PDF eXpress-certified PDF.

Required manuscript inputs:
  main.tex                     Entire paper, author block, and 30 references
  IEEEtran.cls                 IEEE conference class, unchanged
  figure_drafts/*.pdf           The five exact figures referenced by main.tex

The bibliography uses an inline thebibliography environment; no .bib or .bst
file is missing. There are no external TeX subfiles, custom macros in a separate
file, absolute local paths, or required experiment datasets/model weights.
Figures are PDF vector assets with embedded fonts, not EPS inputs. Do not
convert the figure format unless the publication service specifically requires
it; main.tex references these exact PDF filenames.

Tested build in a clean directory:
  tectonic --only-cached --keep-logs main.tex
Engine: Tectonic 0.16.9; cached standard TeX resources available on the test host.
For a fresh Tectonic installation, use `tectonic main.tex` so it may obtain its
standard TeX resources. A normal pdfLaTeX installation is another intended
option (two runs of `pdflatex main.tex`), but was not tested on this host.
Standard packages: fontenc, cite, graphicx, array, amsmath, amssymb, amsfonts,
textcomp, url, hyperref, xcolor. Bibliography processing is not required.

Clean build verification: 8 US-Letter pages; all 8 rendered pages exactly match
the certified PDF at 300 dpi; all character positions/fonts/sizes match after
normalizing subset font prefixes. All font resources are embedded. Existing
Underfull box warnings remain; no Overfull box, missing-glyph, or unresolved
reference errors were found.

The newly rebuilt main.pdf is a local verification output, not a newly certified
PDF. Submit the original returned 2026400920.pdf separately as the final PDF.
Certified PDF SHA256:
afb2406c2e39c8b90aa660b18af709373eacf6a41792c950816809a0b4a27371

The conference publicly requests a PDF and a compressed source archive.
Use the accompanying .tar.gz version when following the listed tar/gzip formats;
the .zip has identical contents and is an alternative only if the form accepts it.
Neither archive includes a signed copyright agreement, registration receipt,
review correspondence, historical drafts, or experimental datasets.

No scientific text, results, figures, references, or author order was changed
during source packaging. IEEEtran's license notice remains inside IEEEtran.cls;
the DejaVu license is included for fonts embedded in the figure assets.
