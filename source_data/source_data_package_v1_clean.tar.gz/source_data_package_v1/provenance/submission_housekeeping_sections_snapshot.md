# Submission Housekeeping Sections v1

Date: 2026-06-04

Current manuscript basis:
- `/Users/teyian/Documents/paper1/manuscript_english_working_draft_v18_submission_reading.md`

Purpose:
- Draft submission-facing statements that are usually required by journals.
- Use conservative placeholders where information is not yet known.
- Avoid inventing author, funding, repository, license or redistribution details.

## Data Availability

Draft:

The analyses used publicly available resources and locally generated processed files. ClinVar variant annotations were obtained from the official NCBI ClinVar FTP `tab_delimited` directory as `variant_summary.txt.gz`; the FTP listing recorded the file release timestamp as 31 March 2024, and the retained copy used in the present rebuild pipeline was archived locally on 3 April 2026. STRING v12 human protein-protein association data and protein sequences were used to construct the PPI graph and homology-aware split. CADD GRCh38 v1.7 whole-genome SNV scores and AlphaMissense hg38 scores were used as external variant-effect predictors. Processed tables supporting the figures, trained-test prediction outputs, summary metric files and figure source data will be made available at `[repository or archive URL to be added]`, subject to the redistribution terms of the original data providers. Large third-party source files, including whole-genome CADD score files, should be obtained from their original providers.

Notes to verify before submission:
- Confirm whether processed ClinVar-derived tables can be redistributed directly or should be shared as scripts plus derived non-identifying summary tables.
- Confirm STRING license/redistribution conditions for graph edge lists and protein identifiers.
- Confirm CADD and AlphaMissense redistribution terms. CADD whole-genome score files are large third-party resources and should probably be referenced rather than mirrored.
- Add final archive/repository URL only after the repository is created.

## Code Availability

Draft:

Code used for data reconstruction, ESM feature generation, graph propagation, model training, statistical analyses and figure generation will be made available at `[repository or archive URL to be added]`. The repository will include scripts for reproducing the main figures and summary tables from processed inputs, together with environment information and instructions for obtaining third-party source data.

Notes to verify before submission:
- Decide whether to release the current script collection as a cleaned GitHub repository, a Zenodo archive, supplementary code, or a combination.
- Separate reproducible scripts from exploratory notebooks or obsolete intermediate scripts.
- Include a minimal README that maps scripts to manuscript figures and supplementary tables.
- Do not promise one-click full regeneration unless the repository actually supports it.

## Supplementary Information

Draft:

Supplementary information should include additional methodological details, architecture-control results, negative-control analyses, repeated-run summaries, calibration and PR-curve summaries, and additional subgroup analyses. The supplement should be organized around reviewer questions rather than chronological experiment order.

Proposed supplementary structure:

1. Supplementary Methods: dataset filtering, identifier mapping, ESM feature generation, graph construction, classifier training, homology-aware split construction and statistical testing.
2. Supplementary Table 1: split sizes, label counts, protein counts and graph statistics.
3. Supplementary Table 2: raw ESM, PPI-GCN, GraphSAGE-style and GAT-style representation-control results.
4. Supplementary Table 3: CADD, AlphaMissense and fusion model performance, including repeated-run summaries.
5. Supplementary Table 4: negative-control and random-control results, including the rerun feature-shuffled GCN control.
6. Supplementary Table 5: homology-aware split metrics and prevalence summary.
7. Supplementary Table 6: topology-stratified and corrected-sample statistical tests.
8. Supplementary Figure 1: PR curves and split-prevalence context.
9. Supplementary Figure 2: calibration/Brier/sensitivity summaries, if retained.
10. Supplementary Figure 3: quartile-stratified CADD and AlphaMissense analyses, if retained.

Notes to verify before submission:
- Avoid a "supplementary black hole"; each item should answer a concrete reviewer concern.
- Keep older random-control results cautious unless provenance is fully documented or rerun.
- Decide whether calibration/clinical-threshold analyses are useful enough to include without implying clinical deployment.

## Author Contributions

Draft template:

`[Author initials]` conceived the study. `[Author initials]` designed the computational experiments. `[Author initials]` performed data reconstruction, model training and statistical analyses. `[Author initials]` generated figures. `[Author initials]` interpreted the results. `[Author initials]` wrote the manuscript with input from all authors. All authors reviewed and approved the final manuscript.

Notes to verify before submission:
- Replace placeholders with real author initials.
- If AI tools contributed to writing or analysis, follow the target journal's AI-tool disclosure policy. Do not list AI as an author.

## Acknowledgements

Draft template:

We thank `[names or groups to be added]` for discussions and feedback. This work used publicly available data from ClinVar, STRING, CADD and AlphaMissense.

Notes to verify before submission:
- Add institutional, advisor, lab or collaborator acknowledgements only if appropriate.
- Add compute-resource acknowledgement if required by AutoDL, institution or funding source.

## Funding

Draft template:

This work was supported by `[funding source and grant number to be added]`.

Alternative if no external funding:

The authors declare that no specific funding was received for this work.

Notes to verify before submission:
- Do not invent funding source or grant number.
- Use the exact funding wording required by the funder, if any.

## Competing Interests

Draft template:

The authors declare no competing interests.

Notes to verify before submission:
- Confirm with all authors before final submission.
- If any author has relevant employment, consulting, equity, patent or paid advisory relationships, this must be disclosed.

## Ethics Statement

Draft:

This study used publicly available aggregate variant annotations and did not involve direct recruitment of human participants, intervention, or access to identifiable individual-level clinical records. Any institutional review requirement should be assessed according to the policies of the authors' institution before submission.

Notes to verify before submission:
- Confirm whether the target journal requires a formal ethics statement even for public-data computational studies.
- Confirm institutional policy before using "not required" language.

## AI Tool Disclosure

Draft template:

During manuscript preparation, AI-assisted tools were used for language editing, organization and drafting support. All scientific claims, numerical results, citations and interpretations were checked by the authors against local analysis outputs or cited sources. AI tools were not used as authors.

Notes to verify before submission:
- Use only if the target journal requires or allows AI-tool disclosure.
- Adjust wording to match the exact journal policy.
- This statement should not imply that AI generated unverified data or results.

## Current Recommendation

Do not merge these sections into the v18 manuscript until the placeholders are resolved. The safest next move is to create a clean repository/expanded archive plan, then fill Data Availability and Code Availability with concrete links and redistribution boundaries.

## Decision Checklist v1

This checklist is kept in the same housekeeping file to avoid creating another small planning file. It records which details must be supplied by the authors before these sections can be moved into the submission manuscript.

### Required before formal submission

1. Repository or archive plan
   - Decision needed: GitHub, Zenodo, OSF, institutional repository, journal supplementary code, or a combination.
   - Current safest path: GitHub for readable code plus Zenodo/OSF archive for a citable frozen version, if the authors are comfortable creating a public repository.
   - Do not write a final URL until the repository/archive exists.

2. Data redistribution boundary
   - Decision needed: whether processed ClinVar-derived variant tables can be shared directly, or whether the repository should provide scripts plus summary/source-data tables.
   - Current conservative wording: third-party source files such as whole-genome CADD scores should be obtained from original providers rather than mirrored.
   - Keep this conservative unless the original licences are checked.

3. Author initials and contribution roles
   - Decision needed: author list and initials.
   - Need to know who did: study conception, experiment design, data reconstruction, model training, statistical analysis, figure generation, manuscript writing and manuscript review.
   - Do not list any AI tool as an author.

4. Funding
   - Decision needed: exact funding source and grant number, or confirmation that no specific funding was received.
   - If no funding: use "The authors declare that no specific funding was received for this work."

5. Competing interests
   - Decision needed: confirmation from all authors.
   - If none: use "The authors declare no competing interests."

6. Ethics statement
   - Decision needed: whether the authors' institution requires a formal review or exemption statement for public-data computational analysis.
   - Current conservative wording avoids saying "ethics approval was not required" until institutional policy is confirmed.

7. AI-tool disclosure
   - Decision needed: target journal policy and author preference.
   - Current truthful core: AI-assisted tools were used for language editing, organization and drafting support; all claims, numbers, citations and interpretations were checked by the authors; AI tools were not authors.

8. Acknowledgements
   - Decision needed: advisor, lab, collaborator, compute platform or institutional acknowledgement.
   - Do not add names without permission.

### Items already reasonably supported

- ClinVar source: official NCBI ClinVar FTP `tab_delimited` directory, file `variant_summary.txt.gz`.
- ClinVar official FTP release timestamp visible in the confirmed listing: 31 March 2024.
- Retained analysis copy archived locally/server-side on 3 April 2026.
- STRING v12, CADD GRCh38 v1.7 and AlphaMissense hg38 are the third-party resources to cite and route users back to.
- Data availability should distinguish figure/source-data tables from large third-party files.

### Recommended wording stance

- Use "will be made available" only after the repository/archive path is practically decided.
- Use "subject to original-provider redistribution terms" for processed data until licences are reviewed.
- Avoid "all data are included" because large CADD/STRING/AlphaMissense files should not be mirrored casually.
- Avoid "fully reproducible from scratch" unless the final code package really contains all scripts, environment information and source-data acquisition instructions.
